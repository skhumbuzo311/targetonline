﻿namespace SmartAutoSpares.Outcomes.Results
{
    public interface IOutcome
    {
    }

    public interface IOutcome<T>
    {
    }
}
